    mapping = {
      chr1  = "hs_ref_chr1.fa.gz",
      chr2  = "hs_ref_chr2.fa.gz"
    }
